package com.cmri.ots.sso;


public class SSoTest {
	
	public static void main(String[] args) {
//		try {
//			System.out.println(AuthUserUtil.publicLogin("liyingcs", "liyingcs","a","a","a"));
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		System.out.println(AuthUserUtil.validLogin("01304abb-f1c2-4100-ad17-28d1e911f184"));
//		System.out.println(AuthUserUtil.getOrgInfo("ac3fd8aa-e25d-48ba-94d6-09d038aa0c9a"));
	}
}
